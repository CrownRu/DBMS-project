<?php
$link=@mysqli_connect(
    'localhost',
    'A1093356',
    'A1093356',
    'A1093356');

    $dbname="A1093356";
    mysqli_query($link,'SET NAMES utf8');
?>
